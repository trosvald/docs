import React from 'react';

export default {
	title: 'Components/Footer',
};

export const editor = () => (
	<div />
	// <LayoutThreeColumnsEditor
	// 	selectorClass={manifest.componentClass}
	// 	layoutThreeColumnsLeft={[
	// 		<CopyrightEditor key={'copyright'} />,
	// 	]}
	// 	layoutThreeColumnsCenter={[
	// 	]}
	// 	layoutThreeColumnsRight={[
	// 	]}
	// />
);
