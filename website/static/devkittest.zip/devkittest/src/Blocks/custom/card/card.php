<?php

/**
 * Template for the Card Block.
 *
 * @package Devkittest
 */

use DevkittestVendor\EightshiftLibs\Helpers\Components;

echo Components::render('card', Components::props('card', $attributes));
