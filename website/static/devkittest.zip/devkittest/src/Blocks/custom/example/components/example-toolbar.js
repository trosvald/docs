import React from 'react';

export const ExampleToolbar = () => {
	return (
		<>
		</>
	);
};
